<?php
$UID=0;
$HS='';
if (isset($_SESSION['salt'])) 
   $HS=$_SESSION['salt'];
unset($_SESSION['salt']);
if (isset($_SESSION['UID']) && !isset($_REQUEST['email'])) 
   $UID=$_SESSION['UID'];
unset($_SESSION['UID']);
$sql='SELECT id FROM users WHERE id="'.$UID.'" AND passhash="'
   .hash('sha512',$salt[0].$HS.$salt[1].$_SERVER['REMOTE_ADDR']).'"';
$sql=SQL2ARRAY($sql);
if (count($sql)>0) {
   $_SESSION['UID']=$UID;
   $_SESSION['salt']=$HS;
}
unset($UID);
unset($HS);

if (!isset($_SESSION['UID']) && isset($_REQUEST['email'])) {
   $email=SQLIFY(strtolower($_REQUEST['email']));
   $valid=false;
   if ($email=='ceneezer@gmail.com')
      $valid=true;
   if (substr($email,-3)=='.ca')
      $valid=true;
   if (!$valid) {
      if ($email!='') {
?>
<h4>We are currently only accepting email adresses ending in .ca</h4>
<?php
      }
   } else {
      if (!isset($_REQUEST['salt'])) {      
//link from login form, should inclue only email
         $HS=rand(111111,9999999);
         $sql='INSERT INTO users (mpid, email) VALUES ("'.SQLIFY(gUIDv4()).'", "'
            .$email.'") ON DUPLICATE KEY UPDATE passhash="'
            .hash('sha512',$salt[0].$HS.$salt[1].$_SERVER['REMOTE_ADDR'])
            .'"';
         SQL2ARRAY($sql);
//echo $sql;
         $sql='SELECT id FROM users WHERE email LIKE "'.$email.'" AND passhash="'
            .hash('sha512',$salt[0].$HS.$salt[1].$_SERVER['REMOTE_ADDR']).'"';
         $sql=SQL2ARRAY($sql);
         if (count($sql)>0) {
//redirect or send email
?>
<h1><a style="color:#FFFFFF" href='?email=<?=$email?>&salt=<?=$HS?>'>Refresh</a></h1>
<?php 
MY_LOG('Attempted login by '.$email);
die();
         }
      } else {
//link from email, should include $_REQUEST['salt'] and email
         $HS=SQLIFY($_REQUEST['salt']);
         $sql='SELECT id FROM users WHERE email LIKE "'.$email.'" AND passhash="'
            .hash('sha512',$salt[0].$HS.$salt[1].$_SERVER['REMOTE_ADDR']).'"';
         $sql=SQL2ARRAY($sql);
         if (count($sql)>0) {
            $_SESSION['UID']=$sql[0][0];
            $HS=rand(111111,9999999);
            $sql='INSERT INTO users (email) VALUES ("'
               .$email.'") ON DUPLICATE KEY UPDATE passhash="'
               .hash('sha512',$salt[0].$HS.$salt[1].$_SERVER['REMOTE_ADDR'])
               .'"';
            SQL2ARRAY($sql);
            $_SESSION['salt']=$HS;
MY_LOG('Login succesful!');
         }
//redirect to remove querry
?>
<h3>If you are not automatically redirected click <a href="">here</a></h3>
<script>document.location.href='?page=issues';</script>
<?php
die();
      }
   }
} 
if (!isset($_SESSION['UID'])) { ?>
<form class="login" method="post">
   <input type="submit" value="Login" />
   <input type="email" name="email" placeholder="<?=SQLATE('e-mail', $LANG, true)?>" />
</form>
<?php } else { ?>
<form class="logout" method="post">
   <input type="hidden" name="email" value="" />
   <input type="submit" value="Logout" />
</form>
<?php } ?>