<?php 
$DBUN='';
$DBPW='';
$DBDB='';
$salt=['change','this'];
?>