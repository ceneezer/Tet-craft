<?php 

//captcha inc.login.pop
/*
#(251, 190, 24, 15)
INSERT INTO issue_votes_popular (ID_user, ID_vote, ID_issue)
SELECT 801, S.rnd, S.ID_issue FROM (select round(avg(i.ID_vote)) as rnd, i.ID_issue FROM issue_votes AS i 
WHERE i.ID_user IN (251, 190, 24, 15, 75, 93, 97, 118, 136, 173, 192, 235, 243, 256, 261, 310, 327, 384, 458) GROUP BY i.ID_issue) AS S
    ON DUPLICATE KEY UPDATE ID_vote=S.rnd

INSERT INTO issue_votes_fringe (ID_user, ID_vote, ID_issue)
SELECT 801, S.rnd, S.ID_issue FROM (select round(avg(i.ID_vote)) as rnd, i.ID_issue FROM issue_votes AS i 
WHERE i.ID_user IN (749, 732, 455, 776, 816, 773, 768, 767, 760, 759, 753, 751, 743, 734, 733, 682, 708, 584, 576) GROUP BY i.ID_issue) AS S
    ON DUPLICATE KEY UPDATE ID_vote=S.rnd

INSERT INTO issue_votes (ID_user, ID_vote, ID_issue)
	SELECT 801, S.rnd, S.ID_issue FROM (
    	select IFNULL(j.ID_vote, i.ID_vote) as rnd, i.ID_issue 
       FROM issue_votes_popular AS i 
			LEFT JOIN issue_votes_fringe AS j ON i.ID_issue=j.ID_issue and j.ID_user=801 
         where i.ID_user=801) AS S
    ON DUPLICATE KEY UPDATE ID_vote=S.rnd
 

KasperKK the racist ghost
KasperKKLGBQ the \(ex)racist\ ghost (rainbow)

?fbclid=

issuevotes needs stamp field, inclued into hash!!!!
*/

SESSION_START();
require '.cfg.php';
require_once '/srv/www/inc.MY_LOG.php';
require_once '/srv/www/inc.SQLATE.php';
require '.cfg.php';
$LANG='en';
if (substr($_SERVER[HTTP_HOST],0,3)=="fr.")
   $LANG="fr";
if (isset($_REQUEST['lang']) && $_REQUEST['lang']=='fr')
   $LANG="fr";
$site='https://voteprism.ceneezer.icu/';

if ($LANG=='fr')
   $meta_desc='Preuve de concept de VotePrism : vote haché sur la blockchain'; //<155 chrs
else
   $meta_desc='VotePrism proof-of-concept: hashed blockchain voting'; //<155 chrs
$meta_t_jpg=$site.'pub/pics/Cansenate.jpg'; //2:1 with minimum dimensions of 300x157 or maximum of 4096x4096 pixels. Images must be less than 5MB in size. JPG, PNG, WEBP and GIF
$meta_fb_jpg=$site.'pub/pics/Cansenate.jpg'; //1.91:1 ratio and minimum recommended dimensions of 1200x630 
$meta_gp_jpg=$site.'pub/pics/Cansenate.jpg'; //??

$PAGE=(isset($_REQUEST['page']))?$_REQUEST['page']:'';
$ID=(isset($_REQUEST['id']))?$_REQUEST['id']:0;
switch($PAGE) {
   case '':
      $title="VotePrism.icu";
      break;
   case 'issue':
      $title=SQLATE('motion', $LANG, true);
      if ($ID>0)
         $title.=' #'.$ID;
      else
         $title=SQLATE('new', $LANG, true).' '.$title;
      break;
   case 'tos':
      $title=SQLATE('terms of service', $LANG, true);
      break;
   case 'privacy':
      $title=SQLATE('privacy policy', $LANG, true);
      break;
   case 'log';
      $title=SQLATE('blockchain', $LANG, true);
      break;
   case 'issues':
      $title=SQLATE('recent motions', $LANG, true);
      break;
   case 'Profile':
      $title=SQLATE('profile', $LANG, true);
      if ($ID>0)
         $title.=' #'.$ID;
      break;
      case 'mine':
      case 'me':
         $title=SQLATE('rankings', $LANG, true);
      break;
}?><!DOCTYPE html><html lang="<?=$LANG?>"><head>
   <meta charset="utf-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1.0" />
   <meta http-equiv="X-UA-Compatible" content="ie=edge" />
   <link rel="stylesheet" href="pub/style.css" />
   <script src="pub/sorttable.js"></script>
<?php require_once '/srv/www/inc.meta.php'; ?>
</head><body>
   <img id="bg" src="pub/pics/Cansenate.jpg" />
   <header>
      <h1><img id="logo" src="pub/pics/logo.png" />otePrism.icu</h1>
      <form class="search" method="post">
<input name="search" value="<?=isset($_REQUEST['search'])?$_REQUEST['search']:''?>" placeholder="<?=SQLATE('search', $LANG, true)?>" />
<input type="submit" value="<?=SQLATE('search', $LANG, true)?>" />
      </form>
      <aside class="flags">
<a href="https://voteprism.ceneezer.icu"><img src="pub/pics/en.jpg" /></a><a href="http://fr.voteprism.ceneezer.icu"><img src="pub/pics/fr.svg" /></a>
      </aside>
      <nav>
         <ul>
            <li><a href="?page=issues"><?=SQLATE('motions', $LANG, true)?></a></li>
            <li><a href="?page=log"><?=SQLATE('blockchain', $LANG, true)?></a></li>
            <li><a href="?page=me"><?=SQLATE('rankings', $LANG, true)?></a></li>
         </ul>
      </nav>
   </header>