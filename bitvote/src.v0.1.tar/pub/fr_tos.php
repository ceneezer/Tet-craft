<?php  require_once '/srv/www/mine/voteprism/inc.head.php'; ?>
   <main>
      <section>
         <pre>
<h3>Utilisez ce site à vos risques et périls !</h3>
En utilisant ce site de preuve de concept, vous nous exonérez, nous, ses propriétaires, opérateurs et autres utilisateurs, de toute responsabilité implicite, responsabilité et protection éthique dans toute la mesure de la loi applicable.
Les seules informations que nous avons sur vous sont fournies soit par vous, soit par le gouvernement.

<strong><em>Cela étant dit, nous ferons de notre mieux pour garder vos informations privées privées.</em></strong>
      </section>
   </main>
<?php  require_once '/srv/www/mine/voteprism/inc.foot.php'; ?>