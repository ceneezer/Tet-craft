<?php  require_once '/srv/www/mine/voteprism/inc.head.php'; ?>
   <main>
      <section>
         <pre>
<h3>Use this site at your own risk!</h3>
By using this proof-of-concept site you exempt us, it's owners, operators and fellow users, of any implied liability, responsibility and ethical protection to the full extent of applicable law.
The only information we have about you is supplied by either you or the government.

<strong><em>That having been said we will try our "best effort" to keep your private information private.</em></strong>
      </section>
   </main>
<?php  require_once '/srv/www/mine/voteprism/inc.foot.php'; ?>