   <footer class="flex">
      <a href="."><?=SQLATE('home', $LANG, true)?></a>|
      <a href="?page=tos"><?=SQLATE('terms of service', $LANG, true)?></a>|
      <a href="?page=privacy"><?=SQLATE('privacy policy', $LANG, true)?></a>|
      <span><?=SQLATE('copyright', $LANG, true)?> &copy; 2014 ceneezer</span>
   </footer>
</body></html>